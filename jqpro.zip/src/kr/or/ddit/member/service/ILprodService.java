package kr.or.ddit.member.service;

import java.util.List;

import kr.or.ddit.member.vo.LprodVO;

public interface ILprodService {

	public List<LprodVO> selectAll();
}
