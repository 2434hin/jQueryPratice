package kr.or.ddit.member.dao;

import java.sql.SQLException;
import java.util.List;

import kr.or.ddit.member.vo.LprodVO;

public interface ILprodDao {

	public List<LprodVO> selectAll() throws SQLException;
}
